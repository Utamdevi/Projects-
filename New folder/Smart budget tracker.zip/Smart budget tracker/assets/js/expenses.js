// assets/js/expenses.js

document.addEventListener("DOMContentLoaded", () => {
  initMobileMenu();
  renderTable();
});

// Load Data and Settings
let transactions = BudgetUtils.loadFromLocalStorage("transactions") || [];
let settings = BudgetUtils.loadFromLocalStorage("settings") || { currency: "NGN" };
let currentCurrency = settings.currency;

let filteredTransactions = [...transactions];
const rowsPerPage = 10;
let currentPage = 1;

// DOM Elements
const tableBody = document.getElementById("transactionsTableBody");
const totalCount = document.getElementById("totalTransactionsCount");
const totalIncome = document.getElementById("totalIncome");
const totalExpenses = document.getElementById("totalExpenses");
const pageInfo = document.getElementById("pageInfo");

// Render Table
function renderTable() {
  tableBody.innerHTML = "";
  const start = (currentPage - 1) * rowsPerPage;
  const paginated = filteredTransactions.slice(start, start + rowsPerPage);

  if (paginated.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="7" class="text-center">No transactions found</td></tr>`;
  }

  paginated.forEach((tx) => {
    const row = document.createElement("tr");
    const catInfo = BudgetUtils.getCategoryInfo(tx.category);
    
    row.innerHTML = `
      <td><input type="checkbox" class="rowCheckbox" data-id="${tx.id}"></td>
      <td>${BudgetUtils.formatDate(tx.date)}</td>
      <td>${tx.name}</td> <td><span class="badge" style="background:${catInfo.color}; color: #fff; padding: 5px 10px; border-radius: 15px;">${catInfo.name}</span></td>
      <td>${tx.type}</td>
      <td class="text-right" style="color: ${tx.type === 'income' ? '#2ecc71' : '#e74c3c'}">
        ${BudgetUtils.formatCurrency(tx.amount, currentCurrency)}
      </td>
      <td>
        <button class="btn btn-sm btn-danger" onclick="deleteTransaction('${tx.id}')">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    `;
    tableBody.appendChild(row);
  });

  updateSummary();
  updatePagination();
}

function updateSummary() {
  totalCount.textContent = filteredTransactions.length;
  let income = 0, expense = 0;

  filteredTransactions.forEach((tx) => {
    tx.type === "income" ? (income += parseFloat(tx.amount)) : (expense += parseFloat(tx.amount));
  });

  // Use BudgetUtils for consistent currency formatting
  totalIncome.textContent = BudgetUtils.formatCurrency(income, currentCurrency);
  totalExpenses.textContent = BudgetUtils.formatCurrency(expense, currentCurrency);
}

function updatePagination() {
  const totalPages = Math.ceil(filteredTransactions.length / rowsPerPage) || 1;
  pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
  document.getElementById("prevPageBtn").disabled = currentPage === 1;
  document.getElementById("nextPageBtn").disabled = currentPage === totalPages;
}

// Event Listeners for Pagination
document.getElementById("prevPageBtn").addEventListener("click", () => {
    if(currentPage > 1) { currentPage--; renderTable(); }
});
document.getElementById("nextPageBtn").addEventListener("click", () => {
    const totalPages = Math.ceil(filteredTransactions.length / rowsPerPage);
    if(currentPage < totalPages) { currentPage++; renderTable(); }
});

// Filters
document.getElementById("applyFiltersBtn").addEventListener("click", () => {
  const cat = document.getElementById("filterCategory").value;
  const type = document.getElementById("filterType").value;
  const year = document.getElementById("filterYear").value;

  filteredTransactions = transactions.filter((tx) => {
    const txYear = new Date(tx.date).getFullYear().toString();
    return (cat === "all" || tx.category === cat) &&
           (type === "all" || tx.type === type) &&
           (year === "all" || txYear === year);
  });

  currentPage = 1;
  renderTable();
});

// Deletion Logic
window.deleteTransaction = function(id) {
    if(confirm("Are you sure?")) {
        transactions = transactions.filter(t => t.id !== id);
        BudgetUtils.saveToLocalStorage("transactions", transactions);
        filteredTransactions = [...transactions]; // Update filtered list
        renderTable();
        BudgetUtils.showNotification("Transaction deleted", "success");
    }
};

function initMobileMenu() {
    // Reuse the mobile menu logic cleanly
    const btn = document.getElementById("mobileMenuBtn");
    const nav = document.getElementById("navLinks");
    if (btn && nav) {
        btn.addEventListener("click", () => nav.classList.toggle("active"));
    }
}